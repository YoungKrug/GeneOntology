﻿#pragma once
#include <string>
#include <fstream>
#include <unordered_map>

class Ontology
{
public:
    enum Type
    {
        TAB_DELINEATED,
        COMMA_DELINEATED
    };
    void ReadOncologyDataBase(std::string, Type);
    void ReadGenes(std::string, Type);
    void ReadChildren(std::string, Type);
    
    std::ifstream OpenFile(std::string);
    std::string DetermineDelimited(Type);
    struct OntologyNode
    {
        std::vector<std::string> children;
        std::vector<std::string> parent;
        std::vector<std::string> otherInformation;
        std::vector<std::string> name;
    };
private:
    std::unordered_map<std::string, std::vector<std::string>> _data;
};
