﻿#include "Ontology.h"

#include <iostream>
void Ontology::ReadOncologyDataBase(std::string path, Type delimiterType)
{
    std::ifstream reader;
    std::string line;
    std::string delimiter = DetermineDelimited(delimiterType);
    reader = OpenFile(path);
    while(std::getline(reader, line))
    {
        size_t pos = 0;
        std::string key;
        bool isFirst = true;
        while ((pos = line.find(delimiter)) != std::string::npos)
        {
            std::string token;
            token = line.substr(0, pos);
            if(isFirst) // will be used as the key
            {
                if(_data.find(token) == _data.end())
                {
                    key = token;
                    //doesnt contain key
                    _data.insert({token, std::vector<std::string>()});
                    isFirst = false;
                }
            }
            else
                _data[key].emplace_back(token);
            line.erase(0, pos + delimiter.length());
        }
        _data[key].emplace_back(line);
    }
}

void Ontology::ReadGenes(std::string path, Type delimiterType)
{
    std::ifstream reader;
    std::string line;
    std::string delimiter = DetermineDelimited(delimiterType);
    reader = OpenFile(path);
    while(std::getline(reader, line))
    {
        size_t pos = 0;
        std::string gene;
        std::string token;
        bool isFirst = true;
        while ((pos = line.find(delimiter)) != std::string::npos)
        {
            token = line.substr(0, pos);
            if(isFirst) // will be used as the key
            {
                gene = token;
                isFirst = false;
            }
            else
                _data[token].emplace_back(gene);
            line.erase(0, pos + delimiter.length());
        }
        _data[token].emplace_back(line);
    }
}

std::ifstream Ontology::OpenFile(std::string path)
{
    std::ifstream reader;
    reader.open(path);
    while(!reader.is_open())
    {
        std::cin >> path;
        reader.open(path);
    }
    return reader;
}

std::string Ontology::DetermineDelimited(Type delimiterType)
{
    switch (delimiterType)
    {
    case TAB_DELINEATED:
        return"\t";
    case COMMA_DELINEATED:
        return ",";
    }
    return "";
}
