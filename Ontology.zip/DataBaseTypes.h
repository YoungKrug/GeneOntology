#pragma once
#include <iostream>
#include <string.h>
#include <vector>
#include <unordered_map>
namespace DataTypes
{
	struct GoInfo
	{
		std::string goAccessionId;
		std::string termidId;
		std::string goSection;
		std::string name;
		void Print()
		{
			std::cout << "Accession Number: " << goAccessionId << "\nTermidID: " << termidId << "\nGoSection: " << goSection << std::endl;
		}
	};
	struct TermidInfo
	{
		std::string termidId;
		std::vector<std::string> childtermidId;
		std::vector<std::string> parentTermidId;
		std::vector<std::string> geneId;
		std::string definition;
		bool isGOI = false;
		void Print(std::unordered_map<std::string ,TermidInfo> _info)
		{
			int GOIs = 0;
			int nGOIs = 0;
			std::string children;
			std::string parents;
			std::string genes;
			for(auto i : childtermidId)
			{
				if(_info[i].isGOI)
					GOIs++;
				else
					nGOIs++;
			}
			if(isGOI)
				GOIs++;
			std::cout << "TermidID: " << termidId << "\nChildren: " << childtermidId.size() <<
				"\nGOIs: " << GOIs << "\nNGOIs: " << nGOIs;
		}
	};

};